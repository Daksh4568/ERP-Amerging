// const mongoose = require ('mongoose')

// const counterMaster = new mongoose.Schema({
//     counterField:{ type : String},
//     counter: { type: Number }
// })

//   // Create and export the model
//   const counters = mongoose.model('counterMaster', counterMaster);
  
//   module.exports = counters;